package com.example.assignment2mad;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;

public class editTable extends home {
    Button add, delete, back;
    Intent intent;
    EditText address, latitude, longitude, deleteA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_table);

        add = findViewById(R.id.add);
        delete = findViewById(R.id.delete);
        back = findViewById(R.id.back);

        add.setOnClickListener(view -> addLoc());
        delete.setOnClickListener(view -> deleteLoc());
        back.setOnClickListener(view -> backPressed());

    }

    private void backPressed() {
        startActivity(new Intent(editTable.this, home.class)); //go back to home page
    }

    public void addLoc() { //send information to the database to add new location
        SQLDB db = new SQLDB(editTable.this);
        db.addLoc(address.getText().toString().trim(),
                latitude.getText().toString().trim(),
                longitude.getText().toString().trim()
        );
    }

    public void deleteLoc() { //send address to delete to the database
        SQLDB db = new SQLDB(editTable.this);
        db.deleteLoc(deleteA.getText().toString().trim());
    }


}

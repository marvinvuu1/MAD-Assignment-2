package com.example.assignment2mad;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class SQLDB extends SQLiteOpenHelper {
    private Context context;
    private static final int DB_VERSION = 1;
    private static final String NAME ="Locations";
    private static final String ID = "id";
    private static final String ADDRESS = "address";
    private static final String LATITUDE = "latitude";
    private static final String LONGITUDE = "longitude";

    public SQLDB (@Nullable Context context) {
        super(context, NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_LOCATION_TABLE = " CREATE TABLE " + NAME + "("
                + ID + " INTEGER PRIMARY KEY," + ADDRESS + " TEXT,"
                + LATITUDE + " TEXT," + LONGITUDE + " TEXT " + ")";
        db.execSQL(CREATE_LOCATION_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    void addLoc(String address, String latitude, String longitude) { //add a new row of information into the table
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(ADDRESS, address);
        cv.put(LATITUDE, latitude);
        cv.put(LONGITUDE, longitude);

        long add = db.insert(NAME, null, cv);
        if(add == -1) {
            Toast.makeText(context,"failed to add new location",Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context,"successfully added new location",Toast.LENGTH_SHORT).show();
        }
    }

    void deleteLoc(String id) { //delete a row of information based on the given address
        SQLiteDatabase db = this.getReadableDatabase();

        String DELETE_LOC = " DELETE FROM " + NAME + " WHERE ID = " + id;
        db.execSQL(DELETE_LOC);
    }
}

package com.example.assignment2mad;

import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class home extends AppCompatActivity {

    EditText searchw;
    Button search, edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        search = findViewById(R.id.searchw);
        searchw = findViewById(R.id.searchw);

        edit.setOnClickListener(view -> startActivity(new Intent(home.this, editTable.class)));
        search.setOnClickListener(view -> search());
    }

    public void search() {
        while(searchw.getText().toString().length() > 0) {
            SQLDB db = new SQLDB(home.this);

        }
    }
}
